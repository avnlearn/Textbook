---
lang: de
polyglossia-lang:
    name: german
    options:
        - spelling=new,babelshorthands=true
...

# Das ist ein Silbentrennungs-Test

Sie studierte in dieser Zeit längst an der weit berühmten Karl-Franzens-Universität Graz.
