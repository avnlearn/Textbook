---
quot-marks-by-lang:
    xxx:
        - LDQUO
        - RDQUO
        - LSQUO
        - RSQUO
quot-lang: xxx
...

This is a "not so simple" test.
For single 'quotes', too.
