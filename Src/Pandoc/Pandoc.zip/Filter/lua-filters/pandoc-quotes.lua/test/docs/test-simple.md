---
quot-marks: „“‚‘
...

This is a "test".
A 'very simple' one.
