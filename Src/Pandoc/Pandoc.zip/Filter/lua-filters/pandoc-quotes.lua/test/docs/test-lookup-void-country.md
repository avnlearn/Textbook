---
lang: de-AT
...

This is "yet another test".
Still a 'simple' one.
