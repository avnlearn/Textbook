# Here is one section

## A subsection

Here is something [@ainsworth:sheppard 27]. And here is something else
[@dames:physiology]. Finally, we want to make sure that we have one last
citation here [@kant:critique2 29].

## Another subsection.

Here is something [@altick:aldine 20]. And here is something repeated
[@dames:physiology].

# Here is another section

Here is something [@lukacs:european 125]. And here is something else
[@cohen:jokes 3]. Finally, we want to make sure that we have one last
citation here [@trollope:autobiography 392].
