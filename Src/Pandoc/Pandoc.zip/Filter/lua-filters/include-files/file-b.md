# File b

This is `file-b.md`.

It has two paragraphs and a header.
